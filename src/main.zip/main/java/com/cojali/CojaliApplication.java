package com.cojali;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CojaliApplication {

	public static void main(String[] args) {
		SpringApplication.run(CojaliApplication.class, args);
	}

}
