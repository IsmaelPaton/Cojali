package com.cojali.controller;

public class AdminController {

}
