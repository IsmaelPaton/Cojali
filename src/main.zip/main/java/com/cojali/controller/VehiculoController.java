package com.cojali.controller;

public class VehiculoController {

}
